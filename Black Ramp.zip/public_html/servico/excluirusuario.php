<?php

include_once "../Banco/bd.php";

$id=$_GET["id"];

$sql = "delete from telalogin where id='$id' ";
$bd = new Bd();
$contador = $bd->exec($sql);

echo "<h1>foi excluído $contador registro</h1>";

?>

<a href="consultausuario.php">Voltar</a>
